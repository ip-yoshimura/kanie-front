<?php
include "header.php"
?>
<?php
include "sidebar.php"
?>
<div class="col-xs-10 col-md-10 no-padding body-background">
    <form>


        <div class="col-xs-12 head-p">
            <p>ＥＸＣＥＬ消費者テータ出力（（おそらく　テータ＞データ））</p>
        </div>
        <div class="col-xs-12 no-padding">

            <div class="col-xs-4 no-padding">


                <div class="col-xs-12 border1 no-padding">

                    <p class="backend">テーブル一覧</p>
                    <div class="col-xs-11" style="height:300px; overflow-y:scroll;">


                        <table class="table table-bordered col-xs-11">
                            <thead class="bg-color">
                            <tr>
                                <th></th>
                                <th>テーブル名</th>

                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="bg-color">1</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">2</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">3</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">4</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">5</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">6</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">7</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">8</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">9</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">10</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">11</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">12</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">13</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">14</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">15</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">16</td>
                                <td></td>

                            </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>


            <div class="col-xs-4">
                <div class="col-xs-12 border1 no-padding">
                    <p class="back-end">
                        未選択</p>
                    <div class="col-xs-11" style="height:300px; overflow-y:scroll;">
                        <table class="table table-bordered col-xs-11">
                            <thead class="bg-color">
                            <tr>
                                <th></th>
                                <th>フィールド名</th>

                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="bg-color">1</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">2</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">3</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">4</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">5</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">6</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">7</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">8</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">9</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">10</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">11</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">12</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">13</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">14</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">15</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">16</td>
                                <td></td>

                            </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

            <div class="col-xs-4">

                <div class="col-xs-12 border1 no-padding">
                    <p class="back-end">未選択</p>
                    <div class="col-xs-11" style="height:300px; overflow-y:scroll;">


                        <table class="table table-bordered col-xs-11">
                            <thead class="bg-color">
                            <tr>
                                <th></th>
                                <th>フィールド名</th>

                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="bg-color">1</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">2</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">3</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">4</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">5</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">6</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">7</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">8</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">9</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">10</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">11</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">12</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">13</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">14</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">15</td>
                                <td></td>

                            </tr>
                            <tr>
                                <td class="bg-color">16</td>
                                <td></td>

                            </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>


        </div>


        <div class="col-xs-12 border1 no-padding bottom-box">
            <p class="backend">選択フィールド</p>
            <div class="tbl-scroll col-xs-12">
                <table class="table table-bordered col-xs-12">
                    <thead>
                    <tr class="bg-color">
                        <th></th>
                        <th class="td-style">フィールド名</th>
                        <th class="td-style">型</th>
                        <th class="td-style">取得元</th>
                        <th class="td-style">'=条件</th>
                        <th class="td-style"><>条件</th>
                        <th class="td-style">範囲開始</th>
                        <th class="td-style">範囲終了</th>
                        <th class="td-style">非出力</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <th class="td-style">1</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">2</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">3</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">4</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">5</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">6</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">7</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">8</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">9</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">10</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>
                    <tr>
                        <th class="td-style">11</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="margin-top:2px;" class="td-style"><input type="checkbox"><span
                                    style="margin-top:5px;">checkbox</span></th>
                    </tr>


                    </tbody>
                </table>
            </div>
            <?php
            include "footer.php"
            ?>


    </form>


</div>


</body>

</html>