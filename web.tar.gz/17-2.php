<?php
include "header.php"
?>

<?php
include "sidebar.php"
?>

<div class="col-xs-10 col-md-10 no-padding  body-background">


        <div class="col-xs-12 " style="margin-bottom:25px;">
	    <div class="head-p">
		<p>EXCEL消費者テータ出力</p>
	    </div>

            <div class="col-xs-12">
                <span style="margin-left:11.8%;color: black">UFJへ送信したデータを選択してください</span><br><br>
            </div>
            <div class="col-xs-12">

                <div class="col-xs-12">
                    <div class="col-xs-12">
                        <div class="col-xs-8 col-xs-offset-1">
                            <input type="text" class="form-control">

                        </div>
                        <div class="col-xs-2 ">
                            <button class="form-control" style="background:#CCCCCC;">場所</button>

                        </div>

                    </div>
                    <div class="col-xs-12" style="margin-top:5px;">
                        <div class="col-xs-1"></div>
                        <div class="col-xs-6 col-xs-offset-1">
                            <input type="text" class="form-control" style="background:#CCCCCC;">

                        </div>
                        <div class="col-xs-5"></div>
                    </div>
                    <div class="col-xs-12" style="margin-top:5px;">
                        <div class="col-xs-3"></div>
                        <div class="col-xs-2 col-xs-offset-1">
                            <button class="form-control" style="background:#CCCCCC;">実行</button>

                        </div>
                        <div class="col-xs-7"></div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12" style="margin-top:50px;">

                <div class="col-xs-12">
                    <div class="col-xs-12">
                        <div class="col-xs-8 col-xs-offset-1">
                            <input type="text" class="form-control">
                        </div>
                        <div class="col-xs-2  ">
                            <button class="form-control" style="background:#F1F1F1;">場所</button>
                        </div>

                    </div>
                    <div class="col-xs-12" style="margin-top:5px;">
                        <div class="col-xs-1"></div>
                        <div class="col-xs-6 col-xs-offset-1">
                            <input type="text" class="form-control" style="background:#CCCCCC;">
                        </div>
                        <div class="col-xs-5"></div>
                    </div>
                    <div class="col-xs-12" style="margin-top:5px;">
                        <div class="col-xs-3"></div>
                        <div class="col-xs-2 col-xs-offset-1">
                            <button class="form-control" style="background:#F1F1F1;">変換</button>
                        </div>
                        <div class="col-xs-7"></div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12" style="margin-top:50px;">

                <div class="col-xs-12">
                    <div class="col-xs-12">
                        <div class="col-xs-8 col-xs-offset-1">
                            <input type="text" class="form-control">
                        </div>
                        <div class="col-xs-2 ">
                            <button class="form-control" style="background:#F1F1F1;">変換</button>
                        </div>
                    </div>
                    <div class="col-xs-12  bottom-box" style="margin-top:5px;">
                        <div class="col-xs-1"></div>
                        <div class="col-xs-6 col-xs-offset-1">
                            <input type="text" class="form-control" style="background:#CCCCCC;">

                        </div>
                        <div class="col-xs-5"></div>
                    </div>
                    <div class="col-xs-12" style="margin-top:5px;">
                        <div class="col-xs-3"></div>
                        <div class="col-xs-2 col-xs-offset-1">
                            <button class="form-control" style="background:#F1F1F1;">実行</button>

                        </div>
                        <div class="col-xs-7"></div>
                    </div>
                </div>
            </div>
        </div>


        <?php
        include "footer.php"
        ?>

        </form>
    </div>
</div>
</div>
</div>

</body>

</html>
