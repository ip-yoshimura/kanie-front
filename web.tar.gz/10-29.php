<?php include 'header.php';?>
<?php include 'sidebar.php';?>
<div class="col-xs-8 col-md-10 col-xs-12 no-padding">
    <div class="col-md-12 col-xs-12 no-padding ">
        <div class="head-p">
            <p>売上・入金の外部読込</p>
        </div>

        <div class="div1">
            <div class="div2">

                <strong>売上・入金データの外部読込みを開始します。<br/>開始する場合は[実行]を選択してください。
                </strong>

            </div>
        </div>

        <br>
        <br>
        <br>

        <?php include 'footer.php';?>


    </div>
</div>
</div>
</div>

</body>

</html>
