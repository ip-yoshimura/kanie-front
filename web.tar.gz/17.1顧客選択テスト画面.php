<?php
include "header.php"
?>
<?php
include "sidebar.php"
?>
<div class="col-xs-10 col-md-10 no-padding body-background">


    <div class="head-p">
        <p class="">UFJ振替不能データ変換</p>
    </div>


    <div class="container">
        <div class="col-xs-2"></div>
        <div class="col-xs-8" style="border:1px solid; height:300px; margin: 0 auto;margin:60px 0px;">
            <p class="text-center" style="padding-top:130px;">テスト用のフォームです</p>
        </div>
        <div class="col-xs-2"></div>
    </div>


    <?php
    include "footer.php"
    ?>


</div>
</div>
</div>

</body>

</html>