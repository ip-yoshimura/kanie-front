<?php
include "header.php"
?>
<?php
include "sidebar.php"
?>
        <div class="col-xs-10 col-md-10  no-padding">
            <div class="col-xs-12 no-padding head-color">
             <div class="head-p">
                <p>操作履歴 </p>
             </div>

                    <div class="col-xs-12 bottom-box" style="height:600px !important; overflow-y:scroll;">
                            
                            <table class="table table-bordered col-xs-12" style="overflow-x:auto; width: 100%;">
                                <thead class="bg-color">
                                    <tr>
                                        <th class="td-num-style"> </th>
                                        <th class="col-xs-2">日付</th>
                                        <th class="col-xs-2">時刻</th>
                                        <th class="col-xs-1">ユーザ</th>
                                        <th class="col-xs-3">機能</th>
                                        <th class="col-xs-3">操作</th>
                                    </tr>
                                </thead>
        
                                <tbody>
                                    <tr>
                                        <td class="bg-color td-style">1</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">2</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">3</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">4</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">5</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">6</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">7</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">8</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">9</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr>
                                        <td class="bg-color td-style">10</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                    <tr> 
                                        <td class="bg-color td-style">11</td>
                                        <td></td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                        <td> </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>


                <?php
                include "footer.php"
                ?>

    </div>



        </div>
            </div>
        </div>
    </div>
    </div>

</body>

</html>
