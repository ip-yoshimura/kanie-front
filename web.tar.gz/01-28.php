<?php include 'header.php';?>
<?php include 'sidebar.php';?>
<div class="col-xs-8 col-md-10 col-xs-12 no-padding">
    <div class="col-md-12 col-xs-12 no-padding ">
        <div class="head-p">
            <p>顧客選択テスト画面</p>
        </div>

        <div class="div1">
            <div class="div2">

                <strong>引越用検針伝票発行

                </strong>

            </div>
        </div>

        <br>
        <br>
        <br>

        <?php include 'footer.php';?>


    </div>
</div>
</div>
</div>

</body>

</html>
