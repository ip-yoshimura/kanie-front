<?php include 'header.php';?>
<?php include 'sidebar.php';?>
    <div class="col-xs-8 col-md-10 col-xs-12 no-padding">
        <div class="col-md-12 col-xs-12 no-padding body-background">

                <div class="head-p">
                    <p>取込み履歴問合せ</p>

                </div>
                <form id="meter" action="/gas/meter-reading" method="POST">

                    <div class="container col-xs-12 bottom-box">

                        <table class="table table-bordered tbl-30-main">
                            <thead class="tbl-31">
                            <tr>
                                <th style="width: 40px;height: 10px"></th>
                                <th>作成日時

                                </th>
                                <th>取込作業日

                                </th>
                                <th>メーカーコード

                                </th>
                                <th>メーカーコード

                                </th>

                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="tbl-31-tr" style="background-color: yellow;color: black">1</td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>

                            </tr>
                            <tr>
                                <td class="tbl-31-tr">  </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>

                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>

                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>

                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>

                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>

                            </tr>

                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>

                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>

                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            <tr>
                                <td class="tbl-31-tr"></td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td class="col-xs-1"><input type="date" class="form-control tbl-input">

                                </td>
                                <td><input type="number" class="form-control tbl-input">

                                </td>
                                <td><input type="text" class="form-control tbl-input">

                                </td>


                            </tr>
                            </tbody>
                        </table>

                    </div>


                    <?php include 'footer.php';?>

                </form>
            </div>
        </div>
    </div>
</div>

</body>

</html>