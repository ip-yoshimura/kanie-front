<?php include 'header.php';?>
<?php include 'sidebar.php';?>
    <div class="col-xs-8 col-md-10 col-xs-12 no-padding">
        <div class="col-md-12 col-xs-12 no-padding body-background">
                <div class="head-p">
                    <p>振替データ書込</p>
                </div>
                <div class="div1">
                    <div class="div2">

                        <strong>
                           Screenshot not found!

                        </strong>

                    </div>
                </div>


                <br>
                <br>
                <br>

                <?php include 'footer.php';?>


            </div>
        </div>
    </div>
</div>

</body>

</html>