<?php include "header.php"; ?>
<?php include "sidebar.php"; ?>
<div class="col-xs-8 col-md-10 col-xs-12 no-padding">

    <div class="col-md-12 col-xs-12 no-padding head-color">

        <div class="head-p ">
            <p>進捗度合分類保守
            </p>
        </div>
        <form action="/gas/meter-reading" id="meter" method="POST">

            <div class="container tbl-scroll col-xs-12 bottom-box">

                <table class="table table-bordered tbl-30-main">
                    <thead class="tbl-31">
                    <tr>
                        <th></th>
                        <th>No.</th>
                        <th>進捗度合分類名</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="tbl-31-tr col-xs-1">1</td>
                        <td class="col-xs-2"></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">2</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">3</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">4</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">5</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">6</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">7</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">8</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">9</td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="tbl-31-tr">10</td>
                        <td></td>
                        <td></td>
                    </tr>
                    </tbody>
                </table>

            </div>


            <?php include 'footer.php';?>

        </form>
    </div>
</div>
</div>
</div>

</body>

</html>
