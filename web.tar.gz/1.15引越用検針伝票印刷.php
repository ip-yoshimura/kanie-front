<?php include 'header.php'; ?>
<?php include 'sidebar.php'; ?>
<div class="col-xs-10 col-md-10 col-xs-12 no-padding">

    <div class="col-md-12 col-xs-12 no-padding head-color">
        <div class="head-p">
            <p>引越用検針伝票印刷</p>
        </div>

        <div class="div1">
            <div style="text-align: center;margin-right: 223px;">
                <strong>引越用検針伝票印刷</strong>
            </div>

            <div class="div2">
                <div style="margin-top: -120px;margin-left: -120px;">
                    <div class="col-xs-12">
                        <div class="col-xs-3">
                            <p>消費者コード</p>
                        </div>

                        <div class="col-xs-4 no-padding">
                            <div class="form-group">
                                <input id="consumerCodeStartId" name="consumerCodeStartId"
                                       class="form-control"
                                       type="text" />
                            </div>
                        </div>
                    </div>
                </div>

                <div style="margin-top: -120px;margin-left: -120px;">
                    <div class="col-xs-12">
                        <div class="col-xs-3">
                            <p>消消費者名</p>
                        </div>

                        <div class="col-xs-6 no-padding">
                            <div class="form-group">
                                <input id="consumerCodeStartId" name="consumerCodeStartId"
                                       class="form-control"
                                       type="text" />
                            </div>
                        </div>
                    </div>
                </div>

                <div style="margin-top: -120px;margin-left: -120px;">
                    <div class="col-xs-12">
                        <div class="col-xs-3">
                            <p>届け先名</p>
                        </div>

                        <div class="col-xs-6 no-padding">
                            <div class="form-group">
                                <input id="consumerCodeStartId" name="consumerCodeStartId"
                                       class="form-control"
                                       type="text" />
                            </div>
                        </div>
                    </div>
                </div>

                <div style="margin-top: -120px;margin-left: 120px;">
                    <div class="col-xs-12">
                        <div class="col-xs-3">
                            <p>届け先名

                            </p>
                        </div>

                        <div class="col-xs-6 no-padding">
                            <div class="form-group">
                                <strong>0</strong>
                                <strong>件</strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div style="margin-top: -120px;margin-left: 120px;">
                    <div class="col-xs-12">
                        <button name="submit" class="btn  bottom-button-group" ><span class="bottom-padding" style="color: #0f0f0f">追加</span></button>

                        <div class="col-xs-6 ">
                            <button name="submit" class="btn  bottom-button-group"><span class="bottom-padding" style="color: #0f0f0f">削除</span></button>
                        </div>
                    </div>
                </div>


            </div>
        </div>


        <br>
        <br>
        <br>

        <?php include 'footer.php'; ?>


    </div>
</div>


</body>

</html>